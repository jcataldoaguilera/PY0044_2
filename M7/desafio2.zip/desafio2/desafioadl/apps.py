from django.apps import AppConfig


class DesafioadlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'desafioadl'
